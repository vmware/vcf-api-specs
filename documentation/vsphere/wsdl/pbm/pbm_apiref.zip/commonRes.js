var ID_Copyright = "&copy; 2005-2025 Broadcom. All Rights Reserved. The term \"Broadcom\" refers to Broadcom Inc. and/or its subsidiaries.";
var ID_VersionInformation = "Revision 25 March 2025 &nbsp;|&nbsp;VMware Storage Policy API &nbsp;|&nbsp; Version 9.0.0.0";
