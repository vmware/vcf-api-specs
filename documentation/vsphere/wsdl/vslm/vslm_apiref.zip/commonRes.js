/* commonRes.js - The variables in this file are used in the file vim/vmodl/doc/right-pane.html */
/* Each page footer in the API Reference also uses the ID_Copyright and ID_VersionInformation variables. */
/* Whenever you change the variable values for a release, change only the date and the version number itself. The variable values are embedded in text. Do not add additional text. */
/* Version numbers will be of the form "6.7 Beta", "6.7" or "6.7 Update 1". /*

/* ID_Copyright--embedded in the footer for each page. */
var ID_Copyright = "&copy; 2005-2025 Broadcom. All Rights Reserved. The term \"Broadcom\" refers to Broadcom Inc. and/or its subsidiaries.";

/* ID_VersionInformation--embedded in the footer for each page; contains the release date and version. */
var ID_VersionInformation = "Revision 25 March 2025 &nbsp;|&nbsp; Virtual Storage Lifecycle Management API &nbsp;|&nbsp; Version 9.0.0.0";

/* ID_VersionRelease--embedded in the "What's New ..." header. */
var ID_VersionRelease = "9.0.0.0";

/* ID_Version--embedded in the explanation of the "Since ..." label. */
var ID_Version = "9.0.0.0";
