var ID_Copyright = "&copy; 2005-2025 Broadcom. All Rights Reserved. The term \"Broadcom\" refers to Broadcom Inc. and/or its subsidiaries.";
var ID_VersionInformation = "Revision 25 March 2025 &nbsp;|&nbsp; vSphere 9.0.0.0 &nbsp;|&nbsp; vSphere vCenter SMS API 9.0.0.0";
