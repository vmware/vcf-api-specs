var ID_Copyright = "&copy; 2005-2025 Broadcom, Inc. All rights reserved.";
var ID_VersionInformation = "Revision 25  March 2025 &nbsp;|&nbsp; Version 9.0.0.0";

